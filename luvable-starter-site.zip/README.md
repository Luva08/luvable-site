# Lüvable Starter Site

A simple static site you can deploy on Netlify with GitHub auto-deploys.

## Quick start

1. Create a new GitHub repository (public or private).
2. Upload these files (or push via git).
3. In Netlify, **New site from Git** → connect GitHub → choose this repo → deploy.
4. In GoDaddy, point your domain to Netlify and enable SSL in Netlify.

### Netlify Forms
Two forms (`waitlist` and `waitlist-footer`) are enabled via `data-netlify="true"`. Submissions appear in your Netlify dashboard.
